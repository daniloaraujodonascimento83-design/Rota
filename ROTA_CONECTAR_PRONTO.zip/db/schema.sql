CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TYPE user_role AS ENUM ('admin','cliente','entregador','vendedor','transportadora','empresa');
CREATE TYPE operation_status AS ENUM ('draft','pending','accepted','in_transit','completed','cancelled');

CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(120) NOT NULL,
  email VARCHAR(255) NOT NULL UNIQUE,
  phone VARCHAR(30),
  password_hash TEXT NOT NULL,
  role user_role NOT NULL,
  cpf VARCHAR(20),
  cnpj VARCHAR(30),
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE companies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_user_id UUID NOT NULL REFERENCES users(id),
  legal_name VARCHAR(180) NOT NULL,
  trade_name VARCHAR(180),
  cnpj VARCHAR(30) NOT NULL UNIQUE,
  city VARCHAR(120), state VARCHAR(2),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE vip_contracts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES companies(id),
  commission_rate NUMERIC(5,2) NOT NULL DEFAULT 5.00,
  status VARCHAR(20) NOT NULL DEFAULT 'pending',
  accepted_at TIMESTAMPTZ,
  contract_version VARCHAR(30) NOT NULL DEFAULT 'v1',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE delivery_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  requester_user_id UUID NOT NULL REFERENCES users(id),
  driver_user_id UUID REFERENCES users(id),
  pickup_text TEXT NOT NULL,
  dropoff_text TEXT NOT NULL,
  scheduled_at TIMESTAMPTZ,
  price NUMERIC(12,2) NOT NULL,
  commission_amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  status operation_status NOT NULL DEFAULT 'pending',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE loads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  requester_user_id UUID NOT NULL REFERENCES users(id),
  driver_user_id UUID REFERENCES users(id),
  origin_text TEXT NOT NULL,
  destination_text TEXT NOT NULL,
  load_type VARCHAR(120),
  weight_kg NUMERIC(12,2),
  gross_freight NUMERIC(12,2) NOT NULL,
  commission_amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  net_freight NUMERIC(12,2) NOT NULL,
  status operation_status NOT NULL DEFAULT 'pending',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE accountants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL UNIQUE REFERENCES users(id),
  registration_number VARCHAR(80),
  city VARCHAR(120), state VARCHAR(2),
  specialties TEXT[],
  verified BOOLEAN NOT NULL DEFAULT FALSE,
  rating NUMERIC(3,2) NOT NULL DEFAULT 0
);

CREATE TABLE feedback (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  author_user_id UUID NOT NULL REFERENCES users(id),
  operation_type VARCHAR(40),
  rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE wallet_ledger (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  operation_type VARCHAR(40) NOT NULL,
  operation_id UUID,
  entry_type VARCHAR(30) NOT NULL,
  owner_user_id UUID REFERENCES users(id),
  gross_amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  commission_amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  net_amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_delivery_status ON delivery_requests(status);
CREATE INDEX idx_load_status ON loads(status);
CREATE INDEX idx_feedback_created ON feedback(created_at DESC);
