import 'dotenv/config';
import bcrypt from 'bcryptjs';
import pg from 'pg';

const { Pool } = pg;
const email = process.env.ADMIN_EMAIL?.trim().toLowerCase();
const password = process.env.ADMIN_PASSWORD;
const name = process.env.ADMIN_NAME || 'Administrador ROTA';

if (!process.env.DATABASE_URL || !email || !password) {
  console.error('Defina DATABASE_URL, ADMIN_EMAIL e ADMIN_PASSWORD no ambiente.');
  process.exit(1);
}
if (password.length < 12) {
  console.error('ADMIN_PASSWORD precisa ter pelo menos 12 caracteres.');
  process.exit(1);
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: { rejectUnauthorized: false } });
try {
  const hash = await bcrypt.hash(password, 12);
  const result = await pool.query(`
    INSERT INTO users(name,email,password_hash,role)
    VALUES($1,$2,$3,'admin')
    ON CONFLICT(email) DO UPDATE SET name=EXCLUDED.name, password_hash=EXCLUDED.password_hash, role='admin', active=TRUE
    RETURNING id,name,email,role
  `, [name, email, hash]);
  console.log('Administrador provisionado:', result.rows[0]);
} finally {
  await pool.end();
}
