# Conectar o ROTA à internet

## Arquitetura escolhida
- Banco: PostgreSQL gerenciado (Supabase é uma opção simples).
- API: Node/Express deste projeto.
- Hospedagem: Render.
- Frontend: `public/index.html` servido pela própria API.

## 1. Banco
Crie um projeto PostgreSQL no provedor escolhido e execute `db/schema.sql` no SQL Editor.
Copie a connection string PostgreSQL do painel do provedor. Não envie essa senha pelo chat.

## 2. API
Suba este projeto para um repositório Git privado.
No Render, crie um Web Service a partir do repositório. O `render.yaml` já define os comandos básicos.
Configure no painel do Render:
- `DATABASE_URL`: connection string do PostgreSQL
- `JWT_SECRET`: uma string aleatória longa (32+ bytes)
- `CORS_ORIGIN`: domínio público do ROTA
- `ADMIN_EMAIL`: e-mail do administrador
- `ADMIN_PASSWORD`: senha forte do administrador (12+ caracteres)
- `ADMIN_NAME`: nome exibido para o administrador

## 3. Banco e administrador
Depois do primeiro deploy, execute no Shell do serviço:

```bash
npm run create-admin
```

Isso cria/atualiza somente a conta administrativa. O cadastro público não oferece o papel `admin`.

## 4. Teste
Abra:
- `/api/health` para verificar se a API está online.
- `/` para o aplicativo.

Teste cadastro e login antes de ativar pagamentos, GPS ou dados reais.

## 5. Antes do lançamento
Ainda precisam ser integrados e validados:
- domínio HTTPS
- 2FA do administrador
- provedor de pagamentos/split
- mapas e GPS
- notificações
- armazenamento de documentos
- termos jurídicos e contrato VIP
- backups e monitoramento
- política de privacidade/LGPD
- testes de segurança
