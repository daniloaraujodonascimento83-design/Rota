import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import pg from 'pg';
import { z } from 'zod';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const { Pool } = pg;
const pool = process.env.DATABASE_URL ? new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false }) : null;

app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: process.env.CORS_ORIGIN?.split(',').map(s=>s.trim()) || true, credentials: true }));
app.use(express.json({ limit: '200kb' }));
app.use(rateLimit({ windowMs: 15*60*1000, limit: 300, standardHeaders: true, legacyHeaders: false }));

const roleSchema = z.enum(['cliente','entregador','vendedor','transportadora','empresa']);
const registerSchema = z.object({ name:z.string().min(2).max(120), email:z.string().email(), phone:z.string().min(8).max(30).optional(), password:z.string().min(10).max(128), role:roleSchema, cpf:z.string().min(8).max(20).optional(), cnpj:z.string().min(8).max(30).optional() });
const loginSchema = z.object({ email:z.string().email(), password:z.string().min(1) });

function sign(user){ return jwt.sign({ sub:user.id, role:user.role, email:user.email }, process.env.JWT_SECRET, { expiresIn:'12h', issuer:'rota' }); }
function auth(req,res,next){ try { const h=req.headers.authorization||''; if(!h.startsWith('Bearer ')) return res.status(401).json({error:'Não autenticado'}); req.user=jwt.verify(h.slice(7),process.env.JWT_SECRET,{issuer:'rota'}); next(); } catch { return res.status(401).json({error:'Sessão inválida'}); } }
function allow(...roles){ return (req,res,next)=> roles.includes(req.user.role) ? next() : res.status(403).json({error:'Acesso não permitido'}); }

app.get('/api/health', (_req,res)=>res.json({ok:true, service:'ROTA', mode:'production-foundation'}));

app.post('/api/auth/register', async (req,res)=>{
  const parsed=registerSchema.safeParse(req.body); if(!parsed.success) return res.status(400).json({error:'Dados inválidos', details:parsed.error.flatten()});
  if(!pool) return res.status(503).json({error:'Banco de dados ainda não configurado'});
  const d=parsed.data; const hash=await bcrypt.hash(d.password,12);
  try{
    const q=await pool.query('INSERT INTO users(name,email,phone,password_hash,role,cpf,cnpj) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING id,name,email,role',[d.name,d.email.toLowerCase(),d.phone||null,hash,d.role,d.cpf||null,d.cnpj||null]);
    const user=q.rows[0]; res.status(201).json({user,token:sign(user)});
  }catch(e){ if(e.code==='23505') return res.status(409).json({error:'E-mail já cadastrado'}); console.error(e); res.status(500).json({error:'Não foi possível criar a conta'}); }
});

app.post('/api/auth/login', async (req,res)=>{
  const parsed=loginSchema.safeParse(req.body); if(!parsed.success) return res.status(400).json({error:'Dados inválidos'});
  if(!pool) return res.status(503).json({error:'Banco de dados ainda não configurado'});
  const q=await pool.query('SELECT id,name,email,role,password_hash,active FROM users WHERE email=$1 LIMIT 1',[parsed.data.email.toLowerCase()]);
  const user=q.rows[0]; if(!user || !user.active || !(await bcrypt.compare(parsed.data.password,user.password_hash))) return res.status(401).json({error:'E-mail ou senha inválidos'});
  const safe={id:user.id,name:user.name,email:user.email,role:user.role}; res.json({user:safe,token:sign(safe)});
});

app.get('/api/me', auth, async (req,res)=>{
  if(!pool) return res.status(503).json({error:'Banco de dados ainda não configurado'});
  const q=await pool.query('SELECT id,name,email,phone,role,cpf,cnpj,created_at FROM users WHERE id=$1',[req.user.sub]);
  res.json(q.rows[0]||null);
});

app.get('/api/admin/overview', auth, allow('admin'), async (_req,res)=>{
  if(!pool) return res.status(503).json({error:'Banco de dados ainda não configurado'});
  const [u,d,l,c]=await Promise.all([
    pool.query('SELECT COUNT(*)::int AS total FROM users'),
    pool.query('SELECT COUNT(*)::int AS total FROM delivery_requests'),
    pool.query('SELECT COUNT(*)::int AS total FROM loads'),
    pool.query('SELECT COALESCE(SUM(commission_amount),0)::numeric AS total FROM wallet_ledger WHERE entry_type=\'commission\'')
  ]);
  res.json({users:u.rows[0].total,deliveries:d.rows[0].total,loads:l.rows[0].total,commission:c.rows[0].total});
});

app.use(express.static(path.join(__dirname,'../public')));
app.get('*', (_req,res)=>res.sendFile(path.join(__dirname,'../public/index.html')));
app.listen(process.env.PORT||3000,()=>console.log(`ROTA ativo na porta ${process.env.PORT||3000}`));
