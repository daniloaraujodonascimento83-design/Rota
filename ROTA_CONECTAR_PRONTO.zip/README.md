# ROTA — base real de produção

Esta pasta deixa de ser apenas uma simulação visual: existe um backend, autenticação com senha protegida por hash, JWT, controle de papéis, banco PostgreSQL e estrutura financeira/operações.

## Importante
Ainda **não é um serviço público online**. Para virar o ROTA real acessível pela internet, é necessário provisionar um PostgreSQL, configurar as variáveis de ambiente e publicar o servidor em uma hospedagem. Não coloque senhas bancárias, chaves privadas ou segredos no frontend.

## Estrutura
- `public/index.html` — interface atual do ROTA, preservada como ponto de partida visual.
- `server/index.js` — API, autenticação e autorização.
- `db/schema.sql` — banco de dados inicial.
- `.env.example` — configurações necessárias.

## Segurança inicial
- Senhas com bcrypt (12 rounds).
- JWT com expiração.
- RBAC: admin separado dos usuários comuns.
- Helmet, CORS e rate limit.
- Validação de entrada com Zod.
- Valores de comissão separados no modelo financeiro.

## Próximas etapas para produção
1. Criar PostgreSQL gerenciado.
2. Aplicar `db/schema.sql`.
3. Configurar domínio HTTPS.
4. Configurar autenticação/2FA do administrador.
5. Integrar provedor de pagamentos com split.
6. Integrar mapas/GPS.
7. Integrar notificações.
8. Criar termos/contrato VIP revisados por profissional jurídico/contábil.
9. Testes, logs, backups e monitoramento.
10. Publicar PWA para acesso pelo navegador sem instalação.
