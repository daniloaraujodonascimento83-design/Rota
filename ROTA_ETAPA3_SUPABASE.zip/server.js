const express = require("express");
const path = require("path");
const { Pool } = require("pg");

const app = express();
const PORT = process.env.PORT || 10000;

app.use(express.json({ limit: "1mb" }));

let pool = null;

if (process.env.DATABASE_URL) {
  pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    ssl: { rejectUnauthorized: false },
    max: 5,
    idleTimeoutMillis: 30000,
    connectionTimeoutMillis: 10000
  });

  pool.on("error", (err) => {
    console.error("Supabase/PostgreSQL pool error:", err.message);
  });
}

app.get("/api/health", async (req, res) => {
  if (!pool) {
    return res.status(503).json({
      ok: false,
      service: "ROTA",
      databaseConfigured: false,
      database: "not_configured"
    });
  }

  try {
    const result = await pool.query("select now() as server_time");
    return res.json({
      ok: true,
      service: "ROTA",
      databaseConfigured: true,
      database: "connected",
      serverTime: result.rows[0].server_time
    });
  } catch (err) {
    return res.status(503).json({
      ok: false,
      service: "ROTA",
      databaseConfigured: true,
      database: "error",
      error: "Database connection failed"
    });
  }
});

app.use(express.static(path.join(__dirname)));

app.get("*", (req, res) => {
  if (req.path.startsWith("/api/")) {
    return res.status(404).json({ error: "Not found" });
  }
  res.sendFile(path.join(__dirname, "index.html"));
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`ROTA running on port ${PORT}`);
});
